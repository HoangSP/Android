package com.thienhoang.lhu.sql_life;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String DATABASE_NAME = "sqlite.db";

    private String DB_PATH_SUFFIX = "/databases/";

    SQLiteDatabase database = null ;

    ListView lvDanhBa;
    ArrayList<String> arrDanhBa;
    ArrayAdapter<String> adapterDanhBa;

    Button btnThemDB, btnSua , btnXoa;
    TextView txtTen, txtPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        xuLySaoChepCSDLTuAssetVaoMobile();
        addControls();
        addEvents();
        showAllContact();
    }

    private void xuLySaoChepCSDLTuAssetVaoMobile() {
        File dbFile = getDatabasePath(DATABASE_NAME);

        if(!dbFile.exists()){
            try{
                copyDatabaseTuAssets();
                Toast.makeText(MainActivity.this,"Du lieu duoc chep thanh cong",Toast.LENGTH_SHORT).show();

            }catch (Exception ex){
                Toast.makeText(MainActivity.this,ex.toString(),Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void copyDatabaseTuAssets() {
        try{
            InputStream myInput = getAssets().open(DATABASE_NAME);
            String outFileName = layDuongDanLuuTru();
            File f = new File (getApplicationInfo().dataDir+DB_PATH_SUFFIX);
            if(!f.exists()){
                f.mkdir();

            }
            OutputStream myOutPut = new FileOutputStream(outFileName);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = myInput.read(buffer))>0){
                myOutPut.write(buffer,0,len);
            }
            myOutPut.flush();
            myInput.close();
            myOutPut.close();
        }catch (Exception ex){
            Log.e("Loi_SaoChep",ex.toString());
        }
    }

    private String layDuongDanLuuTru() {
        return  getApplicationInfo().dataDir+DB_PATH_SUFFIX+DATABASE_NAME;
    }

    private void addControls() {
        txtTen = findViewById(R.id.txtName);
        txtPhone = findViewById(R.id.txtPhone);
        btnSua = (Button) findViewById(R.id.btnSua);
        btnThemDB = (Button) findViewById(R.id.btnThem);
        btnXoa = (Button) findViewById(R.id.btnXoa);
        lvDanhBa = findViewById(R.id.lvDanhBa);
        arrDanhBa=new ArrayList<>();
        adapterDanhBa = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,arrDanhBa);
        lvDanhBa.setAdapter(adapterDanhBa);
    }

    private void addEvents() {
        btnThemDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xuLyThemDB();
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xuLySuaDL();
            }
        });
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xuLyXoa();
            }
        });
    }

    private void xuLyXoa() {
        database.delete("Contact","ma=?",new String[]{"6"});
        showAllContact();
    }

    private void xuLySuaDL() {
        ContentValues row = new ContentValues();
        row.put("Ten","Tran Nhu Tuyet");
        database.update("Contact",row,"ma=?",new String[]{"3"});
        showAllContact();
    }

    private void xuLyThemDB() {
        ContentValues row = new ContentValues();
        row.put("ten",txtTen.getText().toString());
        row.put("phone",txtPhone.getText().toString());
        long r = database.insert("Contact",null,row);
        Toast.makeText(MainActivity.this,"Vừa thêm 1 dòng dữ liệu r=" +r,Toast.LENGTH_SHORT).show();
        showAllContact();
    }

    private void showAllContact() {
        database = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE,null);
        Cursor cursor1 = database.query("Contact",null,null,null,null,null,null,null );
        arrDanhBa.clear();

        while (cursor1.moveToNext()){
            int ma = cursor1.getInt(0);
            String ten = cursor1.getString(1);
            String phone = cursor1.getString(2);
            arrDanhBa.add(ma+ "-" + ten + "-" + phone);
        }
        cursor1.close();
        adapterDanhBa.notifyDataSetChanged();
    }
}
